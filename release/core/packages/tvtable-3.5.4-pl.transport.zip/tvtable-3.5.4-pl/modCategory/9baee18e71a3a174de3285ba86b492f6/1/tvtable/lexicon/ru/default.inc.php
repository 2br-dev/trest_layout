<?php

$_lang['tvtable'] = 'TVTable';
$_lang['table'] = 'Table';
$_lang['tvtable.add_column'] = 'Добавить столбец';
$_lang['tvtable.del_column'] = 'Удалить столбец';
$_lang['tvtable.add_row'] = 'Добавить строку';
$_lang['tvtable.del_row'] = 'Удалить строку';
$_lang['tvtable.clear_table'] = 'Очистить таблицу';
$_lang['tvtable.clear_table_confirm'] = 'Вы уверены, что хотите очистить таблицу?';
$_lang['tvtable.remove_row_confirm'] = 'Вы уверены, что хотите удалить строку?';
$_lang['tvtable.remove_column_confirm'] = 'Вы уверены, что хотите удалить столбец?';