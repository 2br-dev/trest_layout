<?php

$_lang['tvtable'] = 'TVTable';
$_lang['table'] = 'Table';
$_lang['tvtable.add_column'] = 'Add column';
$_lang['tvtable.del_column'] = 'Remove column';
$_lang['tvtable.add_row'] = 'Add row';
$_lang['tvtable.del_row'] = 'Remove row';
$_lang['tvtable.clear_table'] = 'Clear table';
$_lang['tvtable.clear_table_confirm'] = 'Are you sure want to clear table values?';
$_lang['tvtable.remove_row_confirm'] = 'Are you sure want to remove row?';
$_lang['tvtable.remove_column_confirm'] = 'Are you sure want to remove column?';