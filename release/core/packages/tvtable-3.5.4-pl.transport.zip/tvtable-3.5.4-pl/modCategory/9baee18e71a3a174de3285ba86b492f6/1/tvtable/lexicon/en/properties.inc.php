<?php

$_lang['tvtable_prop_classname'] = 'Table CSS class';
$_lang['tvtable_prop_resource'] = 'Resource ID (current is default)';
$_lang['tvtable_prop_tdTpl'] = "Chunk &lt;td&gt;";
$_lang['tvtable_prop_thTpl'] = 'Chunk &lt;th&gt;';
$_lang['tvtable_prop_trTpl'] ='Chunk &lt;tr&gt;';
$_lang['tvtable_prop_tv'] = 'TV-parameter ID or name';
$_lang['tvtable_prop_wrapperTpl'] = 'Wrapper table chunk';
$_lang['tvtable_prop_bodyClass'] = '&lt;tbody&gt; CSS class';
$_lang['tvtable_prop_tableClass'] = 'Table CSS class';
$_lang['tvtable_prop_headClass'] = '&lt;thead&gt; CSS class';
$_lang['tvtable_prop_head'] = 'Output table with &lt;thead&gt;';
$_lang['tvtable_prop_getY'] = 'Output column by index. You can also specify <strong>first</strong> and <strong>last</strong>';
$_lang['tvtable_prop_getX'] = 'Output row by index. You can also specify <strong>first</strong> and <strong>last</strong>';